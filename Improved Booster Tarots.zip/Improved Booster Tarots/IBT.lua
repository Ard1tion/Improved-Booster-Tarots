--- STEAMODDED HEADER
--- MOD_NAME: Improved Booster Tarots
--- MOD_ID: IBT
--- MOD_AUTHOR: [Ardition]
--- MOD_DESCRIPTION: A Retexture of all of the "booster" tarots to make them look like their effects. Credit to IAmMe for the Empress sprite as well as the ideas for the Hierophant and Lovers, they're the reason this mod exists.

----------------------------------------------
------------MOD CODE -------------------------

function SMODS.INIT.IBT()
    sendDebugMessage("IBT")

    local IBT = SMODS.findModByID("IBT")

    local sprite_tarot = SMODS.Sprite:new('Tarot', IBT.path, 'IBT-Tarots.png', 71, 95, 'asset_atli')
   

    sprite_tarot:register()


end
----------------------------------------------
------------MOD CODE END----------------------